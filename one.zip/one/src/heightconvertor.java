
public class heightconvertor extends javax.swing.JFrame {

    
    public heightconvertor() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        ftlabel = new javax.swing.JLabel();
        fttext = new javax.swing.JTextField();
        inlabel = new javax.swing.JLabel();
        intext = new javax.swing.JTextField();
        convertbttn = new javax.swing.JButton();
        centilabel = new javax.swing.JLabel();
        centitext = new javax.swing.JTextField();
        clearbttn = new javax.swing.JButton();
        exitbttn = new javax.swing.JButton();

        jToggleButton1.setText("jToggleButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Feet and Inches converter to Centimeter");
        setBackground(new java.awt.Color(0, 102, 102));

        ftlabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        ftlabel.setText("Feet");

        inlabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        inlabel.setText("Inches");

        convertbttn.setBackground(new java.awt.Color(102, 102, 102));
        convertbttn.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        convertbttn.setForeground(new java.awt.Color(255, 255, 255));
        convertbttn.setText("Convert To");
        convertbttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                convertbttnActionPerformed(evt);
            }
        });

        centilabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        centilabel.setText("Centimeter");

        centitext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                centitextActionPerformed(evt);
            }
        });

        clearbttn.setBackground(new java.awt.Color(102, 102, 255));
        clearbttn.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        clearbttn.setText("clear");
        clearbttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbttnActionPerformed(evt);
            }
        });

        exitbttn.setBackground(new java.awt.Color(204, 51, 0));
        exitbttn.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        exitbttn.setText("Exit");
        exitbttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbttnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ftlabel)
                            .addComponent(inlabel))
                        .addGap(61, 61, 61)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(intext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fttext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(centilabel)
                        .addGap(28, 28, 28)
                        .addComponent(centitext, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(clearbttn)
                                .addGap(179, 179, 179)
                                .addComponent(exitbttn, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(convertbttn, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ftlabel)
                    .addComponent(fttext, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inlabel)
                    .addComponent(intext, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(convertbttn)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(centilabel)
                    .addComponent(centitext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearbttn)
                    .addComponent(exitbttn))
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void convertbttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertbttnActionPerformed
        double feet,inches, centimeter;

        feet = Double.parseDouble(fttext.getText());
        inches = Double.parseDouble(intext.getText());

        centimeter= feet* 12 +inches * 2.54;
        centitext.setText(String.valueOf(centimeter));

    }//GEN-LAST:event_convertbttnActionPerformed

    private void centitextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_centitextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_centitextActionPerformed

    private void clearbttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbttnActionPerformed
        fttext.setText("");
        intext.setText("");
        centitext.setText("");

    }//GEN-LAST:event_clearbttnActionPerformed

    private void exitbttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbttnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitbttnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(heightconvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(heightconvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(heightconvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(heightconvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new heightconvertor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel centilabel;
    private javax.swing.JTextField centitext;
    private javax.swing.JButton clearbttn;
    private javax.swing.JButton convertbttn;
    private javax.swing.JButton exitbttn;
    private javax.swing.JLabel ftlabel;
    private javax.swing.JTextField fttext;
    private javax.swing.JLabel inlabel;
    private javax.swing.JTextField intext;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
