
package jcalculator;

public class javacalulator extends javax.swing.JFrame {
private double total1= 0.0;
private double total2=0.0;
private char math_operator;

private void getOperator(String btnText){
math_operator = btnText.charAt(0);
total1 = total1 +Double.parseDouble(textdisplay.getText());
textdisplay.setText("");

}
    
    public javacalulator() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        textdisplay = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bttn1 = new javax.swing.JButton();
        bttn4 = new javax.swing.JButton();
        bttn7 = new javax.swing.JButton();
        bttn2 = new javax.swing.JButton();
        bttn5 = new javax.swing.JButton();
        bttn8 = new javax.swing.JButton();
        bttn9 = new javax.swing.JButton();
        bttn6 = new javax.swing.JButton();
        bttn3 = new javax.swing.JButton();
        bttnplus = new javax.swing.JButton();
        bttnminus = new javax.swing.JButton();
        bttnmulti = new javax.swing.JButton();
        bttn0 = new javax.swing.JButton();
        bttnequal = new javax.swing.JButton();
        bttnmod = new javax.swing.JButton();
        bttndiv = new javax.swing.JButton();
        bttnclear = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("C");

        textdisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textdisplayActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        bttn1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn1.setText("1");
        bttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn1ActionPerformed(evt);
            }
        });

        bttn4.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn4.setText("4");
        bttn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn4ActionPerformed(evt);
            }
        });

        bttn7.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn7.setText("7");
        bttn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn7ActionPerformed(evt);
            }
        });

        bttn2.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn2.setText("2");
        bttn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn2ActionPerformed(evt);
            }
        });

        bttn5.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn5.setText("5");
        bttn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn5ActionPerformed(evt);
            }
        });

        bttn8.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn8.setText("8");
        bttn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn8ActionPerformed(evt);
            }
        });

        bttn9.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn9.setText("9");
        bttn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn9ActionPerformed(evt);
            }
        });

        bttn6.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn6.setText("6");
        bttn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn6ActionPerformed(evt);
            }
        });

        bttn3.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn3.setText("3");
        bttn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn3ActionPerformed(evt);
            }
        });

        bttnplus.setBackground(new java.awt.Color(255, 153, 255));
        bttnplus.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        bttnplus.setText("+");
        bttnplus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnplusActionPerformed(evt);
            }
        });

        bttnminus.setBackground(new java.awt.Color(255, 204, 0));
        bttnminus.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        bttnminus.setText("-");
        bttnminus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnminusActionPerformed(evt);
            }
        });

        bttnmulti.setBackground(new java.awt.Color(255, 204, 204));
        bttnmulti.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        bttnmulti.setText("*");
        bttnmulti.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnmultiActionPerformed(evt);
            }
        });

        bttn0.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bttn0.setText("0");
        bttn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttn0ActionPerformed(evt);
            }
        });

        bttnequal.setBackground(new java.awt.Color(204, 204, 255));
        bttnequal.setFont(new java.awt.Font("Yu Gothic", 1, 18)); // NOI18N
        bttnequal.setText("=");
        bttnequal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnequalActionPerformed(evt);
            }
        });

        bttnmod.setBackground(new java.awt.Color(153, 153, 0));
        bttnmod.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        bttnmod.setText("%");
        bttnmod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnmodActionPerformed(evt);
            }
        });

        bttndiv.setBackground(new java.awt.Color(0, 153, 153));
        bttndiv.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        bttndiv.setText("/");
        bttndiv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttndivActionPerformed(evt);
            }
        });

        bttnclear.setBackground(new java.awt.Color(255, 102, 102));
        bttnclear.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        bttnclear.setForeground(new java.awt.Color(255, 255, 255));
        bttnclear.setText("Clear");
        bttnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnclearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bttn7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttn4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bttn5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttn2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn8, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnequal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bttn3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttnmod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bttnminus, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnplus, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(bttndiv, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bttnmulti, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(bttnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttn2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnplus, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttn4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnminus, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttn7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnmulti, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bttn0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttnequal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttnmod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bttndiv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(bttnclear, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textdisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(textdisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>                        

    private void textdisplayActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void bttn1ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn1Text= textdisplay.getText() + bttn1.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn1Text);
    }                                     

    private void bttn2ActionPerformed(java.awt.event.ActionEvent evt) {                                      
         String bttn2Text= textdisplay.getText() + bttn2.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn2Text);
    }                                     

    private void bttn3ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn3Text= textdisplay.getText() + bttn3.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn3Text);
    }                                     

    private void bttn4ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn4Text= textdisplay.getText() + bttn4.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn4Text);
    }                                     

    private void bttn5ActionPerformed(java.awt.event.ActionEvent evt) {                                      
         String bttn5Text= textdisplay.getText() + bttn5.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn5Text);
    }                                     

    private void bttn6ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn6Text= textdisplay.getText() + bttn6.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn6Text);
    }                                     

    private void bttn7ActionPerformed(java.awt.event.ActionEvent evt) {                                      
         String bttn7Text= textdisplay.getText() + bttn7.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn7Text);
    }                                     

    private void bttn8ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn8Text= textdisplay.getText() + bttn8.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn8Text);
    }                                     

    private void bttn9ActionPerformed(java.awt.event.ActionEvent evt) {                                      
         String bttn9Text= textdisplay.getText() + bttn9.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn9Text);
    }                                     

    private void bttn0ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        String bttn0Text= textdisplay.getText() + bttn0.getText();
        String textField= textdisplay.getText();
        textdisplay.setText(bttn0Text);
    }                                     

    private void bttnplusActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
          String button_Text = bttnplus.getText();
          getOperator(button_Text);
    }                                        

    private void bttnequalActionPerformed(java.awt.event.ActionEvent evt) {                                          
         
          
          switch (math_operator){
              case '+':
                       total2=total1 +Double.parseDouble(textdisplay.getText());
              break;
              case '-':
                       total2=total1 +Double.parseDouble(textdisplay.getText());
              break;
              case '*':
                       total2=total1 +Double.parseDouble(textdisplay.getText());
              break;
              case '/':
                       total2=total1 +Double.parseDouble(textdisplay.getText());
              break;
              case '%':
                       total2=total1 +Double.parseDouble(textdisplay.getText());
              break;
              
    }                                         
      textdisplay.setText(Double.toString(total2));
       total1=0;
    }
    private void bttnclearActionPerformed(java.awt.event.ActionEvent evt) {                                          
       total2 =0;
       textdisplay.setText("");
    }                                         

    private void bttnminusActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String button_Text = bttnminus.getText();
          getOperator(button_Text);
    }                                         

    private void bttnmultiActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String button_Text = bttnmulti.getText();
          getOperator(button_Text);
    }                                         

    private void bttndivActionPerformed(java.awt.event.ActionEvent evt) {                                        
        String button_Text = bttndiv.getText();
          getOperator(button_Text);
    }                                       

    private void bttnmodActionPerformed(java.awt.event.ActionEvent evt) {                                        
       String button_Text = bttnmod.getText();
          getOperator(button_Text);
    }                                       

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(javacalulator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(javacalulator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(javacalulator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(javacalulator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new javacalulator().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton bttn0;
    private javax.swing.JButton bttn1;
    private javax.swing.JButton bttn2;
    private javax.swing.JButton bttn3;
    private javax.swing.JButton bttn4;
    private javax.swing.JButton bttn5;
    private javax.swing.JButton bttn6;
    private javax.swing.JButton bttn7;
    private javax.swing.JButton bttn8;
    private javax.swing.JButton bttn9;
    private javax.swing.JButton bttnclear;
    private javax.swing.JButton bttndiv;
    private javax.swing.JButton bttnequal;
    private javax.swing.JButton bttnminus;
    private javax.swing.JButton bttnmod;
    private javax.swing.JButton bttnmulti;
    private javax.swing.JButton bttnplus;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField textdisplay;
    // End of variables declaration                   
}
